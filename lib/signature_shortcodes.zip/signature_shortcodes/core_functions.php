<?php
//PORTFOLIO FILES
require_once 'portfolio/adler.php';
require_once 'portfolio/berend.php';
require_once 'portfolio/claus.php';
require_once 'portfolio/dierk.php';
require_once 'portfolio/ebert.php';
require_once 'portfolio/franz.php';
require_once 'portfolio/gozzo.php';
require_once 'portfolio/hans.php';
require_once 'portfolio/igor.php';
require_once 'portfolio/karl.php';
require_once 'portfolio/leon.php';
require_once 'portfolio/nemo.php';
require_once 'portfolio/quartz.php';
require_once 'portfolio/rein.php';
require_once 'portfolio/stefan.php';
require_once 'portfolio/theo.php';
require_once 'portfolio/velten.php';
require_once 'portfolio/wilmar.php';
require_once 'portfolio/xaver.php';
require_once 'portfolio/york.php';
require_once 'portfolio/zircon.php';


//BLOG FILES
require_once 'blog_posts/adler.php';
require_once 'blog_posts/berend.php';
require_once 'blog_posts/claus.php';
require_once 'blog_posts/dierk.php';
require_once 'blog_posts/ebert.php';
require_once 'blog_posts/gozzo.php';
require_once 'blog_posts/hans.php';
require_once 'blog_posts/igor.php';
require_once 'blog_posts/johan.php';
require_once 'blog_posts/leon.php';
require_once 'blog_posts/moritz.php';
require_once 'blog_posts/nemo.php';
require_once 'blog_posts/orwin.php';
require_once 'blog_posts/quartz.php';
require_once 'blog_posts/stefan.php';
require_once 'blog_posts/theo.php';
require_once 'blog_posts/uno.php';
require_once 'blog_posts/velten.php';
require_once 'blog_posts/wilmar.php';
require_once 'blog_posts/xaver.php';
require_once 'blog_posts/york.php';
require_once 'blog_posts/zircon.php';

?>